# ds-python-linkedin
This is the lab files for ds-python-linkedin

    1-3. [Lab Environment](01_03/start/1-3-LearningNotebooks.ipynb)
    2-1. [Learning Python](02_01/start/2-1-LearningPython.ipynb)
    2-2. [Introducing Pandas](02_02/start/2-2-LearningNotebooks.ipynb)
    2-3. [Exploring Pandas](02_03/start/2-3-Exploring_Pandas.ipynb)
    2-4. [NumPy and SciPy](02_04/start/2-4-NumPy.ipynb)
    3-1. [Scikit-learn Introduction](03_01/start/3-1-Scikit_Introduction.ipynb)
    3-2. [Scikit-learn Clusterig](03_02/start/3-2-Sklearn_Clustering.ipynb)
    3-3. [Scikit-learn Classification](03_03/start/3-3-Sklearn_Classification.ipynb)
    4-1. [Introducing PySpark](04_01/start/4-1-Introducing_PySpark.ipynb)
    4-2. [Introducing PySpark](04_02/start/4-2-Pyspark_mllib.ipynb)
    4-3. [Introducing PySpark](04_03/4-3-Introducing_PySpark.ipynb)

